<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <title>Too Many Requests</title>

  	<style type="text/css">

    	body {
        margin: 0;
        text-align: center;
        font: 1em/1.3em "Lucida Grande", Arial, Arial, sans-serif;
        background-color: #efefef ;
      }


    	div.outer {
    	  font-size: 75%;
    		position: absolute;
    		left: 50%;
    		top: 50%;
    		width: 400px;
    		height: 200px;
    		margin-left: -200px;
    		margin-top: -100px;
    	}

    	.dialog {
    	  padding: 0;
    	  background-color: white;
    	  border-top: 1px solid #ddd;
    	  border-right: 1px solid #ccc;
    	  border-left: 1px solid #ddd;
    	  border-bottom: 1px solid #ccc;
    	}

    	h1 {
    	  font-size: 100%;
    	  background: #000;
    	  color: white;
    	  margin: 0;
    	  padding: 5px 10px;
    	}

    	h1 span {
	      float: right;
				font-size: 75%;
    	  color: #666;
    	}

    	.block {
    	  text-align: left;
    	  width: 250px;
    	  margin: 0 auto;
    	  margin-top: 2em;
    	}

  	</style>

</head>

<body>
<div class="outer">

		<div class="dialog" style="text-align: center;">
			<h1><span>429</span>Too Many Requests</h1>
			<div class="block">
            <p>You have sent too many requests. Try again soon.</p>
      </div>

	 </div>
</div>
</body>
</html>
